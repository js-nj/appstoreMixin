//cnzz 统计
setTimeout(function() {
	var cnzz_protocol = (("https:" == document.location.protocol) ? " https://" : " http://");
	var statistics = document.createElement('span');
	statistics.id = 'cnzz_stat_icon_1262936208';
	document.body.appendChild(statistics);
	var statisticsScript = document.createElement('script');
	statisticsScript.src = cnzz_protocol + 's13.cnzz.com/z_stat.php?id=1262936208';
	statisticsScript.type = 'text/javascript';
	document.body.appendChild(statisticsScript);
}, 500);